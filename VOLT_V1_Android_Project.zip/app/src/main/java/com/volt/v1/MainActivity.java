package com.volt.v1;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private LinearLayout root;
    private int cyan = Color.rgb(0, 220, 255);
    private TextView status;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(12, 15, 24));
        getWindow().setNavigationBarColor(Color.rgb(12, 15, 24));

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(12, 15, 24));
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 28, 24, 24);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("VOLT V1");
        title.setTextColor(cyan);
        title.setTextSize(30);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("ANDROID COMPANION • GAME SETTINGS");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(11);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 4, 0, 24);
        root.addView(subtitle);

        addToggle("ESP PREVIEW", false);
        addToggle("BOX ESP PREVIEW", false);
        addToggle("NAME LABELS PREVIEW", false);
        addToggle("HEALTH BAR PREVIEW", false);
        addToggle("AIM ASSIST SETTINGS", false);

        TextView fovTitle = label("FOV PREVIEW");
        root.addView(fovTitle);
        SeekBar fov = new SeekBar(this);
        fov.setMax(300);
        fov.setProgress(150);
        root.addView(fov);
        TextView fovValue = label("FOV: 150");
        root.addView(fovValue);
        fov.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int value, boolean user) {
                fovValue.setText("FOV: " + value);
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });

        status = label("STATUS: COMPANION READY");
        status.setTextColor(cyan);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 24, 0, 8);
        root.addView(status);

        TextView note = new TextView(this);
        note.setText("This app is a settings/demo companion. It does not inject into Roblox, read game memory, or control other players. Game features must be implemented inside your own Roblox experience.");
        note.setTextColor(Color.rgb(170, 180, 195));
        note.setTextSize(12);
        note.setPadding(8, 16, 8, 8);
        root.addView(note);

        setContentView(scroll);
    }

    private TextView label(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(Color.WHITE);
        v.setTextSize(15);
        v.setPadding(4, 12, 4, 8);
        return v;
    }

    private void addToggle(String name, boolean initial) {
        Switch sw = new Switch(this);
        sw.setText(name);
        sw.setTextColor(Color.WHITE);
        sw.setTextSize(14);
        sw.setPadding(4, 14, 4, 14);
        sw.setChecked(initial);
        sw.setOnCheckedChangeListener((button, checked) -> {
            status.setText("STATUS: " + name + (checked ? " ON" : " OFF"));
        });
        root.addView(sw);
        View line = new View(this);
        line.setBackgroundColor(Color.rgb(38, 51, 70));
        root.addView(line, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 1));
    }
}
